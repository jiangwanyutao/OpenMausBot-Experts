# 页面查询

## 1. pdf.get_pdf_page_count

#### 功能说明

查询指定 PDF 文件的总页数。

**适用于**：在拆页前确认范围是否合法，或当用户明确询问"这个 PDF 有多少页"时调用。

- 当用户给出"提取第 X 到 Y 页"这类要求时，若页数上限未知，先查页数再执行拆页
- 当用户已经明确给出可靠页数范围时，也可以直接调用后续工具
- 这个工具只解决"页数确认"，不负责读取正文内容

#### 调用示例

查询 PDF 页数：

```json
{
  "file_id": "file_pdf_001"
}
```

#### 参数说明

- `url` (string, 三选一必填: `url` / `link_id` / `file_id`): PDF 的 URL
- `link_id` (string, 三选一必填: `url` / `link_id` / `file_id`): PDF 的分享链接 ID
- `file_id` (string, 三选一必填: `url` / `link_id` / `file_id`): PDF 文件 ID

#### 返回值说明

```json
{
  "code": 0,
  "msg": "ok",
  "data": {
    "page_count": 15
  }
}

```

| 字段 | 类型 | 说明 |
|------|------|------|
| `data.page_count` | integer | PDF 总页数 |
