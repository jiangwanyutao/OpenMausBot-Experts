#!/usr/bin/env node

/**
 * BGM Library - Background Music CLI for Remotion Videos
 * Search, filter, and download royalty-free music from ccMixter.
 */

import { program } from 'commander';
import chalk from 'chalk';
import ora from 'ora';
import axios from 'axios';
import https from 'https';
import {
  downloadTrack,
  updateManifest,
  generateAttribution,
  buildManifestEntry,
} from './downloader.js';

// ─── Constants ───────────────────────────────────────────────────────────────

// ccMixter's SSL certificate chain is incomplete, causing "unable to verify
// the first certificate" errors with Node.js default TLS settings.
// We create a custom HTTPS agent that tolerates this.
const httpsAgent = new https.Agent({ rejectUnauthorized: false });
const api = axios.create({ httpsAgent, timeout: 15000 });

const API_BASE = 'https://ccmixter.org/api/query';

/**
 * Predefined tag presets for common video scenarios.
 * Mapped from the original Pixabay BGM categories.
 */
const PRESETS = {
  travel: {
    name: '旅行/Vlog (Travel/Vlog)',
    description: 'Bright, upbeat, rhythmic — perfect for travel vlogs',
    tags: 'upbeat',
  },
  tech: {
    name: '科技/产品 (Tech/Corporate)',
    description: 'Modern, clean, forward-moving — tech demos and corporate',
    tags: 'electronic',
  },
  lofi: {
    name: '咖啡馆/学习 (Café/LoFi)',
    description: 'Relaxed, rhythmic, chill — study, café, lifestyle',
    tags: 'chill',
  },
  food: {
    name: '美食/生活 (Food/Lifestyle)',
    description: 'Warm, light, unobtrusive — cooking and lifestyle',
    tags: 'acoustic',
  },
  workout: {
    name: '运动/健身 (Workout/Fitness)',
    description: 'Strong beat, high energy — gym, sports, motivation',
    tags: 'edm',
  },
};

// Blocked license keywords (case-insensitive)
const BLOCKED_LICENSES = ['noncommercial', 'noderivs', 'no-deriv', 'nc', 'nd'];

// ─── Helpers ─────────────────────────────────────────────────────────────────

/**
 * Check if a license is commercially safe (CC BY or CC BY-SA).
 */
function isCommercialSafe(licenseName) {
  const lower = licenseName.toLowerCase();
  return !BLOCKED_LICENSES.some((kw) => lower.includes(kw));
}

/**
 * Query ccMixter API.
 * @param {Object} params - Query parameters
 * @returns {Array} Track list
 */
async function queryApi(params) {
  const queryParams = new URLSearchParams({
    f: 'json',
    ...params,
  });

  const url = `${API_BASE}?${queryParams.toString()}`;
  const response = await api.get(url);

  if (!Array.isArray(response.data)) {
    throw new Error('Unexpected API response format');
  }

  return response.data;
}

/**
 * Get the best MP3 file from a track's files array.
 * Prefers "Main Mix" or first mp3 file.
 */
function getBestFile(track) {
  if (!track.files || track.files.length === 0) return null;

  // Prefer "Main Mix" or "mp3" nicname
  const mainMix = track.files.find(
    (f) =>
      f.file_nicname?.toLowerCase().includes('main') ||
      f.file_nicname?.toLowerCase() === 'mp3'
  );
  if (mainMix) return mainMix;

  // Fallback: first mp3 file
  const mp3 = track.files.find((f) =>
    f.file_format_info?.['default-ext'] === 'mp3'
  );
  return mp3 || track.files[0];
}

/**
 * Format track info for display.
 */
function formatTrack(track, index) {
  const file = getBestFile(track);
  const duration = file?.file_format_info?.ps || '?';
  const bpm = track.upload_extra?.bpm || '?';
  const tags =
    track.upload_extra?.usertags
      ?.split(',')
      .slice(0, 5)
      .join(', ') || '';

  const lines = [
    `  ${chalk.cyan(`#${index + 1}`)} ${chalk.bold(track.upload_name)} ${chalk.dim(`(ID: ${track.upload_id})`)}`,
    `     ${chalk.dim('Artist:')} ${track.user_real_name || track.user_name}`,
    `     ${chalk.dim('Duration:')} ${duration}  ${chalk.dim('BPM:')} ${bpm}  ${chalk.dim('License:')} ${track.license_name}`,
    `     ${chalk.dim('Tags:')} ${tags}`,
    `     ${chalk.dim('URL:')} ${track.file_page_url}`,
  ];

  return lines.join('\n');
}

/**
 * Format file size for display.
 */
function formatSize(bytes) {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)}MB`;
}

// ─── Commands ────────────────────────────────────────────────────────────────

program
  .name('bgm')
  .description('Background music search & download from ccMixter for Remotion videos')
  .version('1.0.0');

// ── search ───────────────────────────────────────────────────────────────────

program
  .command('search [keywords...]')
  .description('Search ccMixter for background music tracks')
  .option('-l, --limit <n>', 'Max results', '10')
  .option('-p, --preset <name>', 'Use a predefined tag preset (travel, tech, lofi, food, workout)')
  .option('--commercial-only', 'Only show commercially safe licenses (CC BY / CC BY-SA)', true)
  .option('--no-commercial-only', 'Include all licenses')
  .option('--sort <field>', 'Sort by: date, name, score', 'score')
  .action(async (keywords, opts) => {
    const spinner = ora('Searching ccMixter...').start();

    try {
      let tags;
      if (opts.preset) {
        const preset = PRESETS[opts.preset.toLowerCase()];
        if (!preset) {
          spinner.fail(`Unknown preset: ${opts.preset}`);
          console.log(chalk.dim(`Available: ${Object.keys(PRESETS).join(', ')}`));
          process.exit(1);
        }
        tags = preset.tags;
        spinner.text = `Searching with preset "${opts.preset}" (${preset.name})...`;
      } else if (keywords.length > 0) {
        tags = keywords.join(',');
      } else {
        spinner.fail('Provide keywords or --preset');
        process.exit(1);
      }

      const params = {
        tags,
        limit: opts.limit,
        sort: opts.sort,
      };

      // Pre-filter with lic=open for commercial-only
      if (opts.commercialOnly) {
        params.lic = 'open';
      }

      const tracks = await queryApi(params);

      // Double-check license filter in code
      const filtered = opts.commercialOnly
        ? tracks.filter((t) => isCommercialSafe(t.license_name))
        : tracks;

      spinner.stop();

      if (filtered.length === 0) {
        console.log(chalk.yellow('No tracks found matching your query.'));
        return;
      }

      console.log(
        chalk.green(`\nFound ${filtered.length} track(s):\n`)
      );

      for (let i = 0; i < filtered.length; i++) {
        console.log(formatTrack(filtered[i], i));
        if (i < filtered.length - 1) console.log();
      }

      console.log(
        chalk.dim(
          `\nUse ${chalk.cyan('bgm download <ID>')} to download a track.`
        )
      );
    } catch (err) {
      spinner.fail(`Search failed: ${err.message}`);
      process.exit(1);
    }
  });

// ── download ─────────────────────────────────────────────────────────────────

program
  .command('download <uploadId>')
  .description('Download a track by ccMixter upload ID')
  .option('-o, --output <dir>', 'Output directory', './public')
  .option('--force', 'Overwrite existing files', false)
  .action(async (uploadId, opts) => {
    const spinner = ora(`Fetching track ${uploadId}...`).start();

    try {
      // Fetch track metadata
      const tracks = await queryApi({ ids: uploadId });

      if (tracks.length === 0) {
        spinner.fail(`Track not found: ${uploadId}`);
        process.exit(1);
      }

      const track = tracks[0];

      // License check
      if (!isCommercialSafe(track.license_name)) {
        spinner.fail(
          `Track "${track.upload_name}" has license "${track.license_name}" which is NOT commercially safe. Use --force to override.`
        );
        if (!opts.force) process.exit(1);
      }

      const file = getBestFile(track);
      if (!file) {
        spinner.fail('No downloadable MP3 file found for this track.');
        process.exit(1);
      }

      spinner.text = `Downloading "${track.upload_name}" (${file.file_format_info?.ps || '?'})...`;

      const result = await downloadTrack(
        {
          download_url: file.download_url,
          file_page_url: track.file_page_url,
          file_name: file.file_name,
        },
        opts.output,
        { force: opts.force }
      );

      if (result.skipped) {
        spinner.info(
          `"${track.upload_name}" already exists at ${result.filePath} (use --force to overwrite)`
        );
      } else {
        spinner.succeed(
          `Downloaded "${track.upload_name}" → ${result.filePath} (${formatSize(result.size)})`
        );
      }

      // Update manifest & attribution
      const entry = buildManifestEntry(track, file);
      await updateManifest(opts.output, entry);
      await generateAttribution(opts.output);

      console.log(chalk.dim(`  Manifest: ${opts.output}/music_manifest.json`));
      console.log(chalk.dim(`  Attribution: ${opts.output}/ATTRIBUTION.txt`));
      console.log();
      console.log(
        chalk.dim('Remotion usage:')
      );
      console.log(
        chalk.cyan(
          `  <Audio src={staticFile('${file.file_name}')} volume={0.3} loop />`
        )
      );
    } catch (err) {
      spinner.fail(`Download failed: ${err.message}`);
      process.exit(1);
    }
  });

// ── pick ─────────────────────────────────────────────────────────────────────

program
  .command('pick <theme>')
  .description('Auto-pick and download the best match for a video theme')
  .option('-o, --output <dir>', 'Output directory', './public')
  .option('-l, --limit <n>', 'Number of candidates to evaluate', '5')
  .option('--force', 'Overwrite existing files', false)
  .action(async (theme, opts) => {
    const spinner = ora(`Finding best BGM for "${theme}"...`).start();

    try {
      // Map theme keywords to search tags
      const tags = theme
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, '')
        .split(/\s+/)
        .filter(Boolean)
        .join(',');

      const tracks = await queryApi({
        tags,
        lic: 'open',
        limit: opts.limit,
        sort: 'score',
      });

      // Filter for commercial safety
      const safe = tracks.filter((t) => isCommercialSafe(t.license_name));

      if (safe.length === 0) {
        // Fallback: try broader search with just first keyword
        const fallbackTags = tags.split(',')[0];
        spinner.text = `No exact match, trying broader search: "${fallbackTags}"...`;

        const fallback = await queryApi({
          tags: fallbackTags,
          lic: 'open',
          limit: opts.limit,
          sort: 'score',
        });
        const fallbackSafe = fallback.filter((t) =>
          isCommercialSafe(t.license_name)
        );

        if (fallbackSafe.length === 0) {
          spinner.fail('No commercially safe tracks found for this theme.');
          process.exit(1);
        }

        safe.push(...fallbackSafe);
      }

      // Pick the top-scored track
      const picked = safe[0];
      const file = getBestFile(picked);

      if (!file) {
        spinner.fail('No downloadable file found.');
        process.exit(1);
      }

      spinner.text = `Downloading "${picked.upload_name}" by ${picked.user_real_name || picked.user_name}...`;

      const result = await downloadTrack(
        {
          download_url: file.download_url,
          file_page_url: picked.file_page_url,
          file_name: file.file_name,
        },
        opts.output,
        { force: opts.force }
      );

      const entry = buildManifestEntry(picked, file);
      await updateManifest(opts.output, entry);
      const attribution = await generateAttribution(opts.output);

      if (result.skipped) {
        spinner.info(`Already downloaded: ${result.filePath}`);
      } else {
        spinner.succeed(
          `Downloaded "${picked.upload_name}" → ${result.filePath} (${formatSize(result.size)})`
        );
      }

      console.log();
      console.log(formatTrack(picked, 0));
      console.log();
      console.log(chalk.dim('Remotion usage:'));
      console.log(
        chalk.cyan(
          `  <Audio src={staticFile('${file.file_name}')} volume={0.3} loop />`
        )
      );
      console.log();
      console.log(chalk.dim('Attribution:'));
      console.log(
        chalk.dim(
          `  "${picked.upload_name}" by ${picked.user_real_name || picked.user_name} — ${picked.license_name}`
        )
      );
    } catch (err) {
      spinner.fail(`Pick failed: ${err.message}`);
      process.exit(1);
    }
  });

// ── presets ───────────────────────────────────────────────────────────────────

program
  .command('presets')
  .description('List predefined tag presets for common video scenarios')
  .action(() => {
    console.log(chalk.green('\nAvailable BGM Presets:\n'));

    for (const [key, preset] of Object.entries(PRESETS)) {
      console.log(`  ${chalk.cyan.bold(key.padEnd(10))} ${preset.name}`);
      console.log(`  ${' '.repeat(10)} ${chalk.dim(preset.description)}`);
      console.log(`  ${' '.repeat(10)} ${chalk.dim(`Tags: ${preset.tags}`)}`);
      console.log();
    }

    console.log(
      chalk.dim(`Use: ${chalk.cyan('bgm search --preset <name>')} to search with a preset.`)
    );
  });

// ── info ─────────────────────────────────────────────────────────────────────

program
  .command('info <uploadId>')
  .description('Show detailed info about a track')
  .action(async (uploadId) => {
    const spinner = ora(`Fetching track ${uploadId}...`).start();

    try {
      const tracks = await queryApi({ ids: uploadId });

      if (tracks.length === 0) {
        spinner.fail(`Track not found: ${uploadId}`);
        process.exit(1);
      }

      spinner.stop();
      const track = tracks[0];

      console.log();
      console.log(chalk.bold.green(track.upload_name));
      console.log(chalk.dim('─'.repeat(40)));
      console.log(`${chalk.dim('Artist:')}     ${track.user_real_name || track.user_name}`);
      console.log(`${chalk.dim('Upload ID:')}  ${track.upload_id}`);
      console.log(`${chalk.dim('License:')}    ${track.license_name}`);
      console.log(`${chalk.dim('License URL:')} ${track.license_url}`);
      console.log(`${chalk.dim('Page:')}       ${track.file_page_url}`);
      console.log(`${chalk.dim('Artist Page:')} ${track.artist_page_url}`);
      console.log(`${chalk.dim('BPM:')}        ${track.upload_extra?.bpm || 'N/A'}`);
      console.log(`${chalk.dim('Date:')}       ${track.upload_date_format}`);

      const safe = isCommercialSafe(track.license_name);
      console.log(
        `${chalk.dim('Commercial:')}  ${safe ? chalk.green('YES (safe)') : chalk.red('NO (restricted)')}`
      );

      if (track.upload_extra?.usertags) {
        console.log(`${chalk.dim('Tags:')}       ${track.upload_extra.usertags.replace(/,/g, ', ')}`);
      }

      console.log();
      console.log(chalk.dim('Files:'));
      for (const f of track.files || []) {
        const dur = f.file_format_info?.ps || '?';
        const size = f.file_filesize || '?';
        console.log(
          `  ${chalk.cyan(f.file_nicname || 'mp3')} — ${dur} ${size} — ${f.file_name}`
        );
      }
    } catch (err) {
      spinner.fail(`Info failed: ${err.message}`);
      process.exit(1);
    }
  });

program.parse();
