# MultiCloudQ

由腾讯云智能顾问 CloudQ 驱动的多云AIOps专家。

## 类型

Agent 型

## 功能

- 🤖 **全渠道 ChatOps** — 用自然语言管理多云资源，随时随地
- 🤖 **7×24 AIOps** — 智能巡检、风险预警、架构评估，主动决策
- ☁️ **全方位 CloudOps** — 腾讯云、阿里云、AWS、Azure、GCP 统一管理
- 🗺️ **架构可视化** — 自动生成或手动绘制多云架构拓扑图

所有能力由腾讯云智能顾问 CloudQ 多云AIOps专家提供支持。

## 使用示例

- 查询我在各云平台上的资源概况
- 展示我的云架构拓扑图
- 对比各云账号的资源利用率

## 头像

头像在 `avatars/` 目录下。如需替换为自定义头像，要求：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 打包

```bash
zip -r multi-cloud-expert.zip multi-cloud-expert/
```
