> **安全化服务知识（强制）**：本文仅用于理解服务职责、故障阶段、日志文件名与错误关键字。原始资料中的执行片段、认证材料或原始记录索取、内部地址请求、防护绕过和生产写操作已移除。实际核实必须遵守顶层公共规范：获授权、只读、限时限量、租户/资源归属校验、参数绑定、脱敏；不得索取或输出凭据、客户端原始记录和真实内部地址。

# policy-open-api（策略对外 API）· 排障知识库

> 本文档按**服务粒度**独立成库，供 AI 助手消费。policy-open-api = 策略对外 HTTP API。
> 结论四段式：**① 功能逻辑 ② 大概原因 ③ 排障方式 ④ 排不出来给技术人员的信息**。
> 全部来自真实代码分析，AI 只引用不编造。

---

## 〇、服务定位

policy-open-api = **策略对外 HTTP API**。含 old_endpoint_control(describe/delete/spa 策略等)子模块。

### 日志文件

| 用途 | 路径 |
|---|---|
| 主日志 | `/data/services/pcmgr_enterprise/logs/policy-open-api/policy-open-api.log` |
| 错误 | `.../policy-open-api/error_policy-open-api.log` |
| fatal | `.../policy-open-api/fatal_policy-open-api.log` |

### 串联查询字段：RequestId、TenantId、PolicyId。

---

## 一、功能逻辑：策略对外 HTTP API，含 old_endpoint_control 子模块。

---

## 二、故障场景库

### 场景 A：接口异常
**③ 排障方式**：在 `error_policy-open-api.log` 按子路由查 controller/describe_policy 等报错。
> [安全化移除] 原始资料中的执行片段、敏感材料索取或变更步骤已删除；仅可按公共规范进行只读、限时、脱敏核实。

---

## 三、给 AI 的输出规范

> [安全化移除] 原始资料中的执行片段、敏感材料索取或变更步骤已删除；仅可按公共规范进行只读、限时、脱敏核实。

---

> 本文档由 AI 基于真实代码库分析生成，重要决策请经专业人员核验。

---
> [安全化移除] 原始资料中的执行片段、敏感材料索取或变更步骤已删除；仅可按公共规范进行只读、限时、脱敏核实。

---

## 相关数据表（供 AI 分析）

> policy-open-api 本身不持表，读写同策略主链。
> 策略真源：**policy** / **policy_item** / **policy_template**（见 policy-calculate 页）。