# 单必成 - 销售教练

全栈销售教练：从能力培养到实战执行——会议准备、交易策略、商业案例、竞品分析、通话复盘，用苏格拉底式提问驱动。

## 核心能力

- **销售代表培养**：基于 Richardson 框架的个性化辅导计划
- **Pipeline Review**：结构化检视辅导，从数量管理转向质量管理
- **通话辅导与复盘**：基于证据的行为反馈 + 跟进邮件生成
- **交易策略**：MEDDPICC 诊断、采购委员会图谱、风险登记册
- **商业案例构建**：客户导向的 ROI 叙事和价值模型
- **竞品分析**：Battle Card、定位对比、异议处理话术
- **会议准备**：全面的会前简报和应对策略
- **预测纪律**：基于证据的 Commit/Upside 管理

## 内置技能

| 技能 | 功能 | 触发方式 |
|------|------|---------|
| `prepare-meeting` | 客户会议准备简报 | "帮我准备会议" |
| `deal-strategy` | 交易策略包（地图+委员会+风险+行动） | "帮我做交易策略" |
| `business-case` | 客户商业案例和 ROI 分析 | "帮我做商业案例" |
| `competitive-brief` | 竞品分析和 Battle Card | "帮我分析竞品" |
| `call-debrief` | 通话复盘 + 教练反馈 + 跟进 | "帮我复盘通话" |
| `anti-distill` | 去 AI 味处理 | "帮我去 AI 味" |

## 致谢

本专家在构建过程中参考并借鉴了以下开源项目，特此致谢：

- [agency-agents](https://github.com/msitarzewski/agency-agents)（MIT License）
- [anti-distill](https://github.com/leilei926524-tech/anti-distill)（MIT License）

相关开源许可证文本见 [`license/`](./license) 目录。
