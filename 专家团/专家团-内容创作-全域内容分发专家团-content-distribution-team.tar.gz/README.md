# 全域内容分发专家团

一站式多平台内容分发解决方案，覆盖 12+ 全球社交媒体平台。

## 类型

Team 型（5人专家团）

## 功能

全域内容分发专家团专注于帮助创作者、品牌方和企业将内容高效分发到全球 12+ 社交媒体平台。核心能力包括：

- **多平台发布规则适配**：精通各平台的内容规格、审核规则和发布限制
- **日历排期管理**：科学规划发布时间、频率和节奏
- **批量发布编排**：支持同步/错峰/梯度等多种发布策略
- **跨平台数据分析**：统一数据口径，跨平台效果对比和归因分析
- **多账号管理**：矩阵号运营、设备指纹防关联、账号安全防护

### 支持平台

**国内平台**：抖音、小红书、快手、B站、微信公众号

**国际平台**：TikTok、YouTube、Instagram、X (Twitter)、LinkedIn、Pinterest、Facebook、Threads

## 技能

| 技能名 | 说明 |
|--------|------|
| multi-platform-distribution | 多平台内容分发完整知识体系，含发布规则、排期策略、数据分析和账号管理 |

## 团队成员

| 角色 | 名称 | 职责 |
|------|------|------|
| 主理人 | 安拓(Atlas) - 分发策略师 | 多平台分发策略制定、发布节奏规划、团队调度、数据复盘 |
| 国内平台专家 | 晓红(Ruby) | 抖音/小红书/快手/B站发布规则与内容适配 |
| 国际平台专家 | 格罗(Glow) | TikTok/YouTube/Instagram/X/LinkedIn/Pinterest/Facebook/Threads 发布规则与优化 |
| 排期运营专家 | 凯历(Calendar) | 日历排期管理、批量发布编排、最佳时间策略 |
| 分发数据分析师 | 达维(Davis) | 多平台数据聚合分析、发布效果评估、优化建议 |

## 使用示例

- "帮我把这条视频同时发布到抖音、小红书和 TikTok"
- "为我制定一周的内容发布排期计划"
- "分析我上周各平台的发布数据表现"
- "这条横版视频如何适配到竖版平台？"
- "帮我评估各平台的 ROI，决定资源分配"

## 工作流程

```
Phase 1: 分发策略制定
    ↓ 确定目标平台和优先级
Phase 2: 平台适配
    ↓ 国内/国际平台内容适配
Phase 3: 排期与执行
    ↓ 日历排期 + 批量发布
Phase 4: 数据分析
    ↓ 效果追踪 + 优化建议
Phase 5: 综合报告
```

## 头像

头像待生成，将放置在 `avatars/` 目录下。如需替换为自定义头像，要求：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 打包

```bash
zip -r content-distribution-team.zip content-distribution-team/
```

## 致谢

本专家团封装并引用了以下开源技能与第三方服务：

- `humanizer` 技能：遵循 MIT License，内容基于 Wikipedia "Signs of AI writing"（CC BY-SA）。
- `wechat-article-search`、`mp-draft-push` 技能：源自 [wechat-ai-publisher](https://github.com/bbwdadfg/wechat-ai-publisher)（MIT License, Copyright bbwdadfg）。
- `multi-platform-distribution` 技能：本仓原创知识库。
- `xiaohongshu` 技能：调用外部 `xiaohongshu-mcp` 服务。
- `libtv-skill` 技能：封装 LibTV / LiblibAI OpenAPI（liblib.tv），受其服务条款约束。

各许可证全文见 `license/` 目录。本专家团在原始内容基础上进行了适配与修改。
