# 学术选刊顾问团 v3.1

## 概述

五人学术选刊顾问团，采用**并行双管道架构**（中文刊管道 + 外文刊管道），为研究人员提供高质量的期刊选刊投稿建议。

### v3.1 更新内容

| 修复项 | 说明 |
|--------|------|
| **API URL编码修复** | 所有GET请求参数值必须URL编码（encode），修复中文关键词/刊名导致的API调用失败 |
| **curl调用规范** | 统一使用 `curl -G URL --data-urlencode "key=value"` 方式，自动编码参数 |
| **版本号同步** | plugin.json 版本号从3.0.0更新为3.1.0 |
| **settings.json** | API密钥已解码为明文authValue，开箱即用 |

### v3.0 核心升级

| 能力 | v2.1.0 | v3.0 |
|------|:---:|:---:|
| 证据层数 | 2层 | **4层**（L1秒拒+L2引用+L3匹配+L4语义） |
| 关键词热度评估 | ❌ | ✅ 实时5关键词热度 |
| 语义嵌入搜索 | ❌ | ✅ vectorParameter向量搜索 |
| 范式识别 | ❌ | ✅ 7种研究范式 |
| 审稿周期精度 | 直接取值 | **三级降级实时计算** |
| 录用概率精度 | 直接取值 | **多维度修正估算** |
| 评审模拟 | ❌ | ✅ 按需调用 |
| 专家数 | 7人 | **5人**（+1按需） |

## 架构

```
主理人（甄刊明）
├── 论文特征提取 + 范式识别
├── 关键词热度评估（5次文献检索API）
├── 语义嵌入搜索（1次vectorSearch，共享双管道）
│
├── 中文刊管道
│   ├── 刊探（cn-pipeline-scout）：搜索+L1秒拒+L2引用指纹
│   └── 刊评（cn-pipeline-matcher）：L3匹配+L4排序+冲稳保策略
│
├── 外文刊管道
│   ├── 刊搜（en-pipeline-scout）：搜索+L1秒拒+L2引用指纹
│   └── 刊策（en-pipeline-matcher）：L3匹配+L4排序+冲稳保+预警
│
└── 审言（paper-reviewer）：评审模拟（按需）
```

## 使用示例

1. **常规选刊投稿**：
   > 我写了一篇关于光纤通信中PSA优化算法的论文，目标SCI期刊，摘要：...[粘贴摘要]...，全文：[上传]

2. **仅外文刊方案**：
   > 我的论文质量属于中等偏上，请为我制定SCI/SSCI"冲-稳-保"投稿方案

3. **评审模拟**（需先完成选刊推荐）：
   > 请模拟Optics Express的同行评审，帮我预判审稿人可能提出的问题

## 数据源

- **万方刊寻API**：期刊数据（检索、详情、发文偏好、趋势、机构分布等）
- **万方文献检索API**：语义嵌入搜索、关键词热度评估、审稿周期实时计算
- 域名和认证信息见 `settings.json` 的 `apiConfig`

## 4层证据体系

| 层级 | 名称 | 数据来源 | 用途 |
|------|------|---------|------|
| L1 | 秒拒排除 | 刊寻API detail | 语言/基金/学科确定性排除 |
| L2 | 引用指纹 | 论文参考文献 | 学术生态圈定位 |
| L3 | 多维匹配 | 刊寻API 7个子接口 | 6维度特征匹配+录用概率 |
| L4 | 语义嵌入 | 文献检索API vectorSearch | 内容相似度校准 |

## 7种研究范式

计算建模型 / 实验验证型 / 实证调查型 / 诠释论证型 / 混合方法型 / 系统综述型 / 综合交叉型

范式配置文件：`references/paradigm_profiles/`

## 安装

1. 将 zip 包解压到 WorkBuddy 插件目录
2. 确保 `settings.json` 中的 `apiConfig` 包含有效的万方API凭证
3. 在 WorkBuddy 中启用"学术选刊顾问团 v3.1"专家

## API 认证

插件内置默认万方 API 凭证（`settings.json` → `apiConfig.authValue`），开箱即用。如需使用自己的密钥：

```json
{
  "agent": "academic-journal-selector-team-lead",
  "apiConfig": {
    "baseUrl": "https://api.wfdata.com",
    "authHeader": "X-Ca-AppKey",
    "authValue": "你的万方AppKey"
  }
}

## 辅助脚本

包内 `scripts/` 提供两个可选辅助脚本（**非运行时必需**，仅用于管理 API 凭证）：

- `encode_apikey.py`：将你的万方 AppKey 编码后写入 `settings.json` 的 `apiConfig.authValue`。
- `decode_apikey.py`：读取并解码 `settings.json` 中的 `apiConfig.authValue`（仅做 base64 混淆，非加密，请勿随意外传）。

运行时专家直接从 `settings.json` 的 `apiConfig` 读取凭证，无需执行上述脚本。
```
