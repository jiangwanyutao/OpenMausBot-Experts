# 中文法律咨询团 (chatlaw-team)

> 借鉴北京大学 ChatLaw 多智能体架构，6 位专业角色分 4 阶段协作的中文法律咨询专家团

## 类型

**Team 型** — 6 人团队（1 主理人 + 5 成员）

## 功能

融合北大 ChatLaw 项目"知识图谱 + 专家混合（MoE）+ 多智能体协作"的核心思想，提供高准确度的中文法律咨询服务。SOP 贯穿：

1. **信息采集** → 方助理（info-intake）结构化追问案情
2. **法律研究** → 周法官（legal-research）和沈判官（case-precedent）并行检索法条与判例
3. **综合建议** → 钱顾问（advice-writer）撰写法律建议
4. **咨询报告** → 苏文书（report-finalizer）整合终稿

适合民事、婚姻家庭、合同争议、劳动、侵权等高频法律场景。

## 团队成员

| 角色 | 名称 | 职责 |
|------|------|------|
| 主理人 | 林律师（Lin） | 首席法律顾问，协调 SOP 执行 |
| 案情采集 | 方助理（Iris） | 结构化问询，抽取案情关键事实 |
| 法条研究 | 周法官（Rex） | 定位适用法条，标注层级与生效日期 |
| 判例分析 | 沈判官（Cara） | 检索判例，提炼裁判规则 |
| 建议撰写 | 钱顾问（Adam） | 综合法条判例，出具法律建议 |
| 报告终稿 | 苏文书（Fiona） | 按咨询报告模板最终成稿 |

## 使用示例

- "我们要离婚，请帮我做一份法律咨询报告"
- "公司没付加班费，我该怎么追讨？"
- "邻居装修漏水弄坏了我的东西，怎么索赔？"

## 质量标准

输出的法律咨询报告在 6 个维度达到专业水准：
- 完整性（Completeness）
- 逻辑性（Logic）
- 正确性（Correctness）
- 语言质量（Language Quality）
- 指导性（Guidance）
- 权威性（Authority）

## 源项目致谢

本专家团的角色划分思路借鉴自：
- [PKU-YuanGroup/ChatLaw](https://github.com/PKU-YuanGroup/ChatLaw)（北京大学袁粒团队，AGPL-3.0）

本专家团为原创实现，未复制源项目代码；所有 MD 与 JSON 均为 WorkBuddy 独立撰写。

## License & Acknowledgements

This expert references the following project. Full license/attribution notes are
provided under the `license/` directory. Summary:

| Resource | Usage | License |
|----------|-------|---------|
| [PKU-YuanGroup/ChatLaw](https://github.com/PKU-YuanGroup/ChatLaw) | Architectural inspiration only (multi-agent role division) | AGPL-3.0 |

> Note: `chatlaw-team` references ChatLaw **only as an architectural/conceptual
> inspiration**. No ChatLaw source code, model weights, datasets, or other
> AGPL-3.0-licensed materials are copied, bundled, or derived at the code level.
> All agent prompts (`agents/*.md`) and JSON are original work by the WorkBuddy
> Team. Since this expert is not a derivative of ChatLaw's source, the AGPL-3.0
> copyleft obligations (incl. Section 13) are not triggered. See
> `license/ChatLaw-AGPL-3.0-reference-only.LICENSE`.

## 免责声明

本专家团输出的法律建议**不构成正式法律意见**。涉及重大权益、刑事、涉外、资本市场等专业场景，请委托执业律师。

## 打包

```bash
zip -r chatlaw-team.zip chatlaw-team/
```
