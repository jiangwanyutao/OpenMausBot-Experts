---
name: interactive-medical-case
description: 将一篇诊疗指南/医学文献改写为可交互的 H5 互动病例（手机端、微信小程序风格的单文件 HTML）。适用于医学学术推广、医生（HCP）继续教育、病例教学等场景：用户提供一篇诊疗指南文章或医学文献，本 skill 生成一个让医生"从学到练"的模拟诊疗互动——封面→患者病情→逐题作答（3~5 题，含循证解析与认知卡点识别）→方案解析→学习小结。当用户提到"互动病例""把指南做成互动病例""病例学习""模拟诊疗""interactive medical case""把这篇指南/文献生成可互动的病例"等需求时使用本 skill。
agent_created: true
---

# 互动病例生成 (Interactive Medical Case)

## 这个 skill 是做什么的

把一篇**诊疗指南/医学文献**转化为一个**可交互的 H5 互动病例**（单文件 HTML，手机竖屏、微信小程序风格）。
产物让医生在模拟诊疗中 step-by-step 做决策，每步给出循证解析，并识别医生的**认知卡点**。

交互流程（固定五段式，题目数量可裁剪）：
```
封面页（标题/导语/作者） → 病情内容（患者详情+检查影像）
  → 互动问答（3~5 题，每题作答后展示循证解析+卡点判定）
  → 方案解析（综合点评+治疗方案+核心要点） → 学习小结（作答分析+卡点汇总）
```

## 何时使用

- 用户提供一篇诊疗指南/医学文献（PDF/Word/文本/链接），要求生成互动病例。
- 用户说"把这篇指南做成互动病例""生成一个可互动的病例""模拟诊疗病例"等。
- 用于医学学术推广、HCP 继续教育、学术会议互动、病例教学工具等。

## 工作流程

### Step 1：获取并理解来源文献
- 用户提供文件时，先读取解析（PDF 用 fitz/pdfplumber skill，Word 用 docx skill，链接用 WebFetch skill）。
- 通读全文，提炼出文献想传达的 **3~5 个核心诊疗观念**，以及每个观念的循证依据（指南推荐、关键研究数据、机制）。
- 详细方法见 `references/authoring_guide.md`。

### Step 2：撰写病例数据 case.json
- 严格按 `references/case_schema.md` 定义的结构生成 `case.json`。
- 关键原则（务必先读 `references/authoring_guide.md`）：
  - 构建一个能"触发"所有核心观念讨论的虚拟患者（患者载体可合理虚构，**诊疗观念与循证必须来自文献**）。
  - 每个核心观念对应一道互动题，题目顺序遵循临床决策链路（诊断→治疗目标→治疗策略→临床获益→用药安全→随访管理）。
  - 每个选项标注 `concept`（correct/partial/miss/wrong/open）以支持卡点分析；每题至少 1 个 `correct`。
  - 题目对应一个 `conceptId`/`conceptName`，选项可标 `grade`(1~5 观念分级)，支撑"题目关联继承"与观念分级验证（学习小结会自动汇总）。
  - 从文献节点转化为题目时，遵循 `references/authoring_guide.md` 中的"节点→题目映射规则"，保证自动转化可复现。
  - 每题配 `evidence`（结论+循证要点+出处），循证要点必须能在来源文献中找到依据，**严禁编造**。
  - 始终保留 `source.disclaimer` 免责声明。全部内容用简体中文。
- 把 `case.json` 写到工作目录（当前 workspace），便于用户留存与二次编辑。

### Step 3：构建单文件 HTML
运行构建脚本（会先校验结构，再注入模板）：
```bash
python scripts/build_case.py <case.json 路径> -o <输出.html 路径>
```

> **运行环境**：仅需 Python 3（脚本只用标准库 `json`/`sys`/`os`/`argparse`），无任何第三方依赖，无需 `pip install`。可用 `python scripts/build_case.py examples/sample_case.json -o test.html` 验证。
- 脚本会输出校验告警/错误；有 error 必须修正 case.json 后重跑，warning 酌情处理。
- 模板在 `assets/template.html`，数据驱动，无需手改模板即可适配任意病例。
- 若需自定义样式，可改模板，但保留 `__CASE_DATA__` 占位符。

### Step 4：预览交付
- 用 `present_files` 展示生成的 HTML（会自动开启实时预览面板）。
- 简要告知用户：哪些内容来自文献循证、哪些是合理虚构的病例载体；以及还可在哪些环节二次配置。

## 资源说明

- `references/case_schema.md` —— 病例数据 `case.json` 的完整字段定义与校验要点。**生成数据前必读。**
- `references/authoring_guide.md` —— 如何从文献提炼观念、设计卡点选项、撰写循证的方法论。**生成前必读。**
- `assets/template.html` —— 手机端互动病例 HTML 模板（含 `__CASE_DATA__` 注入点），数据驱动渲染五段式流程。
- `scripts/build_case.py` —— 校验 case.json 并注入模板生成单文件 HTML 的构建脚本。
- `examples/sample_case.json` —— 一个完整的样例病例，可作为生成新病例时的结构参考。

## 红线（务必遵守）
- 循证结论、指南推荐、研究数据、药品适应症/剂量必须来自来源文献，**不得编造**；文献不足以支撑的题宁可删除。
- 不使用营销夸大、绝对化表述（"最佳""唯一""彻底治愈"等）。
- 内容全部简体中文，始终保留 AI 生成免责声明。
