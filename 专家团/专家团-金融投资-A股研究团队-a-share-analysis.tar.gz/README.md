# a-share-analysis

**A股研究团队** — CodeBuddy Agent Teams Plugin

---

## 简介

8 位研究专家 + 6 个预设 Workflow，覆盖 A 股投资分析全链路。主理人根据用户问题自动选择合适的 Workflow 编排多个成员串并行协作，也支持直接调用单个成员解决单一问题。

## 团队成员

| Emoji | 头衔 | 名字 | 擅长领域 |
|-------|------|------|---------|
| 🎯 | 研究总监 | 顾问全 | 意图识别、Workflow 编排、成员调度 |
| 🌐 | 宏观策略师 | 宏观宏 | 宏观环境、政策解读、传导路径推演 |
| 📺 | 市场解读师 | 盘面清 | 盘面复盘、主线识别、情绪周期、风格轮动 |
| 🔬 | 个股研究员 | 研一深 | 基本面深度、财报解读、公司质地评分 |
| 🧮 | 估值定价师 | 估得准 | PE Bands/PEG估值、分红回报、同行对比 |
| 🔗 | 产业链分析师 | 链知全 | 产业链拆解、核心环节、标的分层、出海 |
| 💰 | 资金行为分析师 | 追聪明 | 北向资金、机构持仓、拥挤度、资金共识 |
| 🏥 | 风险诊断师 | 诊有方 | 风险体检、泡沫识别、仓位决策、调仓建议 |

## 6 个预设 Workflow

| Workflow | 触发问法 | 编排 |
|----------|---------|------|
| 个股深度研究 | "宁德时代能不能买" | 个股+估值+资金 并行 → 风控串行 |
| 每日市场策略 | "今天怎么看" | 宏观+盘面 并行 → 资金验证 |
| 板块比较选方向 | "AI vs 新能源" | 产业链+宏观 并行 → 资金+估值验证 |
| 持仓诊断 | "帮我看看持仓" | 多股并行快检 → 风控汇总 |
| 沿主线找标的 | "沿AI主线找机会" | 盘面锚定 → 产业链展开 → 估值+资金过滤 |
| 宏观传导分析 | "美联储降息影响" | 宏观传导 → 产业链展开 → 估值+资金验证 |

单一问题（如"贵不贵""北向在买什么"）直接调对应成员，不走 Workflow。

## 使用示例

- "帮我梳理下宁德时代的基本面和估值"
- "今天市场怎么看？"
- "AI和新能源哪个方向更好？"
- "帮我诊断下持仓"
- "沿着AI主线找找机会"
- "美联储降息影响哪些行业？"
- "北向资金最近在买什么？"

## 数据来源

- 优先使用 `westock-data` / `westock-tool` 获取实时行情数据
- 降级使用 WebSearch 搜索公开信息
- 所有数据必须来自真实查询，禁止编造

## License & Acknowledgements

The bundled `westock` skill includes packaged (vendored) third-party libraries.
Full license texts are provided under the `license/` directory. Summary:

| Resource | Usage | License |
|----------|-------|---------|
| [garycourt/uri-js](https://github.com/garycourt/uri-js) | Vendored dependency in westock skill | BSD-2-Clause |
| [ajv-validator/ajv](https://github.com/ajv-validator/ajv) | Vendored dependency in westock skill | MIT |
| [nodejs/require-in-the-middle](https://github.com/nodejs/require-in-the-middle) | Vendored dependency in westock skill | MIT |

---

> ⚠️ **免责声明**：本插件所有输出内容由 AI 基于公开信息整理生成，仅供参考，不构成任何投资建议或个股推荐。投资有风险，决策需谨慎。
